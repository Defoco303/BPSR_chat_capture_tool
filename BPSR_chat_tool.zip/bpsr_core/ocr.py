from __future__ import annotations
import re
from PIL import Image
import pytesseract
import numpy as np


def bbox_from_ocr_data(bin_img: np.ndarray, lang: str = "jpn", psm: int = 7, oem: int = 1):
    """Return (x0,y0,x1,y1) bbox of any recognized text in the image.

    Best-effort helper to locate the actual scope label width inside a manually
    specified ROI.
    """
    if bin_img is None:
        return None
    try:
        cfg = f"--oem {int(oem)} --psm {int(psm)}"
        data = pytesseract.image_to_data(
            Image.fromarray(bin_img), lang=lang, config=cfg, output_type=pytesseract.Output.DICT
        )
        n = len(data.get("text", []))
        xs0, ys0, xs1, ys1 = [], [], [], []
        for i in range(n):
            txt = (data["text"][i] or "").strip()
            if not txt:
                continue
            try:
                conf = float(data.get("conf", ["-1"] * n)[i])
                if conf < 0:
                    continue
            except Exception:
                pass
            x = int(data["left"][i])
            y = int(data["top"][i])
            w = int(data["width"][i])
            h = int(data["height"][i])
            if w <= 0 or h <= 0:
                continue
            xs0.append(x)
            ys0.append(y)
            xs1.append(x + w)
            ys1.append(y + h)
        if not xs0:
            return None
        return (min(xs0), min(ys0), max(xs1), max(ys1))
    except Exception:
        return None

def ocr_string_from_bin(bin_img: np.ndarray, lang: str = "jpn", psm: int = 6, oem: int = 1) -> str:
    """Run Tesseract OCR on a binarized (uint8) image."""
    if bin_img is None:
        return ""
    try:
        cfg = f"--oem {int(oem)} --psm {int(psm)}"
        return pytesseract.image_to_string(Image.fromarray(bin_img), lang=lang, config=cfg)
    except Exception:
        return ""

def extract_scope_hint(raw: str) -> str:
    """Extract scope label from OCR text. Returns '[ワールド]' etc or ''."""
    try:
        if not raw:
            return ""
        lines = [l.strip() for l in (raw or "").splitlines() if l.strip()]
        if not lines:
            return ""

        bracket_chars = r"\[\]【】（）\(\)〔〕｛｝\{\}\|｜Iil1"
        dash_chars = r"ー—‐―\-一"

        def _norm(s: str) -> str:
            return re.sub(r"\s+", "", (s or ""))

        for line in lines[:6]:
            compact = _norm(line)
            up = compact.upper()

            if re.match(rf"^[{bracket_chars}]*ワ[{dash_chars}]?ルド", compact) or ("WORLD" in up):
                return "[ワールド]"
            if re.match(rf"^[{bracket_chars}]*ギルド", compact) or ("GUILD" in up):
                return "[ギルド]"
            if re.match(rf"^[{bracket_chars}]*パ[{dash_chars}]?テ(ィ|イ)", compact) or ("PARTY" in up):
                return "[パーティ]"
            if (re.match(rf"^[{bracket_chars}]*(チャネル|チャンネル|チヤネル)", compact) or ("CHANNEL" in up)):
                return "[チャネル]"

            l2 = line.lstrip()
            if not re.match(r"[\[【\(\{〔｛\|｜Iil1]", l2):
                continue

            if re.match(rf"^[{bracket_chars}]*ワ[{dash_chars}]?ルド", compact) or ("WORLD" in up):
                return "[ワールド]"
            if re.match(rf"^[{bracket_chars}]*ギルド", compact) or ("GUILD" in up):
                return "[ギルド]"
            if re.match(rf"^[{bracket_chars}]*パ[{dash_chars}]?テ(ィ|イ)", compact) or ("PARTY" in up):
                return "[パーティ]"
            if (re.match(rf"^[{bracket_chars}]*(チャネル|チャンネル|チヤネル)", compact) or ("CHANNEL" in up)):
                return "[チャネル]"

        return ""
    except Exception:
        return ""
