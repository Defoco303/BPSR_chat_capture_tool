from __future__ import annotations

import re
from typing import List, Dict

from .ocr import extract_scope_hint

# Supported scopes (used for coloring / routing in the UI)
SUPPORTED_SCOPES = ("[ワールド]", "[ギルド]", "[パーティ]", "[チャネル]")


def _is_ascii_word_char(ch: str) -> bool:
    """A-Z a-z 0-9 _"""
    if not ch:
        return False
    o = ord(ch)
    return (
        48 <= o <= 57
        or 65 <= o <= 90
        or 97 <= o <= 122
        or ch == "_"
    )


def smart_join_lines(lines: List[str]) -> str:
    """
    Join OCR lines into a single string.
    - Default: concatenate without spaces (Japanese chat often wraps by newline).
    - If both boundary chars are ASCII word chars, insert a space.
    """
    out = ""
    for part in lines:
        part = (part or "").strip()
        if not part:
            continue
        if not out:
            out = part
            continue
        if _is_ascii_word_char(out[-1]) and _is_ascii_word_char(part[0]):
            out += " " + part
        else:
            out += part
    return out.strip()


def normalize_content_text(text: str) -> str:
    # Collapse repeated spaces/tabs (keep single spaces if they existed)
    s = (text or "").strip()
    s = re.sub(r"[ \t]+", " ", s)
    return s.strip()


def clean_speaker_line(line: str) -> str:
    """
    Speaker line is the first line in bubble.
    The scope icon is masked, but OCR may still put junk at the start.
    Also, speaker name shouldn't contain spaces -> take first token.
    """
    s = (line or "").strip()
    s = re.sub(r"^[^a-zA-Z0-9\u3040-\u30ff\u4e00-\u9faf]+", "", s).strip()
    s = re.split(r"\s+", s, maxsplit=1)[0].strip()
    return s


def is_plausible_name(name: str) -> bool:
    if not name:
        return False
    n = name.strip()
    if len(n) < 1 or len(n) > 24:
        return False
    if not re.search(r"[A-Za-z\u3040-\u30ff\u4e00-\u9faf]", n):
        return False
    digits = sum(ch.isdigit() for ch in n)
    if len(n) >= 6 and digits / max(1, len(n)) > 0.6:
        return False
    if len(n) >= 12 and re.fullmatch(r"[A-Za-z0-9\-_]+", n):
        has_lower = any("a" <= ch <= "z" for ch in n)
        digits_ratio = digits / max(1, len(n))
        if (not has_lower) and digits_ratio >= 0.2:
            return False
    return True


def is_plausible_content(content: str) -> bool:
    c = (content or "").strip()
    if not c:
        return False
    if len(c) > 500:
        return False
    if re.fullmatch(r"[\W_]+", c):
        return False
    return True


# OCR sometimes leaks the scope label into the content line.
# We strip ONLY known scope words. OCR may insert spaces between characters and may
# misread brackets as |, I, l, ], [, 「, 」, etc. We DO NOT strip () or 【】 per spec.
_SCOPE_WORDS = ["ワールド", "ギルド", "パーティ", "チャネル", "チャンネル"]

def _spaced_word(word: str) -> str:
    # Allow arbitrary whitespace between characters (e.g. 'ワ ー ル ド').
    return r"\s*".join(re.escape(ch) for ch in word)

_SCOPE_WORDS_ALT = "(?:" + "|".join(_spaced_word(w) for w in _SCOPE_WORDS) + ")"

# Markers that OCR often substitutes for brackets around the scope label.
# Include ASCII l and fullwidth ｌ just in case.
_SCOPE_MARKERS = r"[\[\]\|｜Ilｌ「」]"

# Strip patterns like:
#   ワールド| , ワールドl , |「ワールドI , [|「 ワール ド] , ] , l , |  etc.
# NOTE: OCR may insert whitespace BETWEEN marker characters (e.g. "| 「ワール ド]").
#       Therefore we allow interleaved whitespace around markers.
_SCOPE_MARKERS_MAYBE_SPACED = rf"(?:\s*{_SCOPE_MARKERS}\s*)*"

# IMPORTANT:
# We require at least ONE trailing marker after the scope word.
# Otherwise OCR noise like "| 「ワール ド]" may partially strip only the scope word and leave
# a leading "]" (or similar), which then survives and appears in UI.
_SCOPE_NOISE_RE = re.compile(
    rf"^\s*{_SCOPE_MARKERS_MAYBE_SPACED}{_SCOPE_WORDS_ALT}(?:\s*{_SCOPE_MARKERS}\s*)+",
    re.UNICODE,
)

# Lines that are *only* a (possibly broken) scope label (no actual message text).
# This catches cases like "[ワールド" (missing closing bracket) or "ワールドl" where
# the whole OCR line is just the scope fragment.
_SCOPE_ONLY_RE = re.compile(
    rf"^\s*{_SCOPE_MARKERS_MAYBE_SPACED}{_SCOPE_WORDS_ALT}{_SCOPE_MARKERS_MAYBE_SPACED}\s*$",
    re.UNICODE,
)

# Also strip leading garbage characters that OCR may produce at the start of a line
# even when no scope word follows.
_LEADING_JUNK_RE = re.compile(r"^\s*[\|｜Ilｌ\]]+\s*", re.UNICODE)


def strip_scope_prefix(line: str) -> str:
    """Remove leading scope-like noise (limited to known scopes) from a line."""
    s = (line or "").lstrip()
    # If the line is *only* a scope fragment, drop it entirely.
    if _SCOPE_ONLY_RE.match(s):
        return ""
    # We iterate a couple of times because after stripping a leaked scope label,
    # a new leading junk marker may become visible (e.g. "]").
    for _ in range(3):
        # 1) Drop a leaked scope label if present.
        s = _SCOPE_NOISE_RE.sub("", s, count=1)
        # 2) Drop leading junk markers (|, I, ]) even if no scope word follows.
        s = _LEADING_JUNK_RE.sub("", s, count=1)
        if _SCOPE_ONLY_RE.match(s):
            return ""
    return s.strip()


def parse_text_multi(raw: str) -> List[Dict[str, str]]:
    """
    Parse OCR text (low-threshold) into messages.
    Expected bubble format:
      1st line: speaker
      2nd line: [scope] + content
      following lines: content continuation
    Also handles the case where two bubbles were merged (best-effort) by splitting on scope lines.
    """
    msgs: List[Dict[str, str]] = []
    lines = [l.strip() for l in (raw or "").splitlines() if l.strip()]
    if len(lines) < 2:
        return msgs

    # Find indices that look like scope+content lines.
    scope_idxs = []
    for i, line in enumerate(lines):
        if extract_scope_hint(line):
            scope_idxs.append(i)

    if scope_idxs:
        for si, idx in enumerate(scope_idxs):
            if idx <= 0:
                continue
            speaker = clean_speaker_line(lines[idx - 1])
            if not is_plausible_name(speaker):
                continue

            scope = extract_scope_hint(lines[idx]) or ""
            # Strip scope-like noise not only on the first content line but also on
            # subsequent wrapped lines (OCR sometimes emits a standalone scope fragment
            # line like "[ワールド" or "| 「ワール ド]" before the real message).
            content_parts = [strip_scope_prefix(lines[idx])]
            # Collect until next scope line (or end)
            end = scope_idxs[si + 1] if si + 1 < len(scope_idxs) else len(lines)
            for j in range(idx + 1, end):
                nxt = lines[j].strip()
                if not nxt:
                    continue
                content_parts.append(strip_scope_prefix(nxt))

            content = normalize_content_text(smart_join_lines(content_parts))
            if is_plausible_content(content):
                msgs.append({"name": speaker, "scope": scope, "content": content})

        if msgs:
            return msgs

    # Fallback: treat as single bubble with first line speaker and rest content.
    speaker = clean_speaker_line(lines[0])
    if not is_plausible_name(speaker):
        speaker = "?"
    content = normalize_content_text(smart_join_lines([strip_scope_prefix(x) for x in lines[1:]]))
    if is_plausible_content(content):
        # try detect scope in the content line if present
        scope = extract_scope_hint(lines[1]) if len(lines) >= 2 else ""
        if scope:
            content = normalize_content_text(
                smart_join_lines([strip_scope_prefix(x) for x in [lines[1]] + lines[2:]])
            )
        msgs.append({"name": speaker, "scope": scope or "", "content": content})
    return msgs


def parse_text_with_scope_hint(raw: str, scope_hint: str) -> List[Dict[str, str]]:
    """
    If we already have a scope from high-threshold ROI, parse speaker+content from low-threshold OCR.
    """
    msgs: List[Dict[str, str]] = []
    lines = [l.strip() for l in (raw or "").splitlines() if l.strip()]
    if len(lines) < 2:
        return msgs
    speaker = clean_speaker_line(lines[0])
    if not is_plausible_name(speaker):
        return msgs

    # Content often starts from line[1] (may include [scope] prefix; strip it anyway)
    content_parts = [strip_scope_prefix(x) for x in lines[1:]]
    content = normalize_content_text(smart_join_lines(content_parts))
    if is_plausible_content(content):
        msgs.append({"name": speaker, "scope": scope_hint or "", "content": content})
    return msgs


def parse_text_fallback_single(raw: str) -> List[Dict[str, str]]:
    """
    Worst-case fallback: return one message with speaker '?', content = entire cleaned text.
    """
    s = normalize_content_text(smart_join_lines([l.strip() for l in (raw or "").splitlines() if l.strip()]))
    if not s:
        return []
    # Best effort: detect scope and strip it from content
    scope = extract_scope_hint(s)
    if scope:
        s = normalize_content_text(strip_scope_prefix(s))
    return [{"name": "?", "scope": scope or "", "content": s}]