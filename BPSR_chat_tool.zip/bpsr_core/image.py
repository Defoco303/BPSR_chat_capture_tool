from __future__ import annotations
import cv2
import numpy as np

def binarize_with_threshold(frame_bgr: np.ndarray, threshold: int, scale: float = 1.0):
    """
    Convert BGR frame to binarized image for OCR.
    Returns (bin_ocr_scaled, bin_prev_original_size, used_scale).
    - bin_ocr_scaled is in scaled coordinates (if scale>1.0)
    - bin_prev is always original size (for preview/detection overlays)
    """
    if frame_bgr is None:
        raise ValueError("frame_bgr is None")
    gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)

    try:
        s = float(scale)
    except Exception:
        s = 1.0
    if s < 1.0:
        s = 1.0

    proc = gray
    if s > 1.0:
        proc = cv2.resize(proc, None, fx=s, fy=s, interpolation=cv2.INTER_CUBIC)

    thr = int(max(0, min(255, int(threshold))))
    _, bin_ocr = cv2.threshold(proc, thr, 255, cv2.THRESH_BINARY)

    if s > 1.0:
        bin_prev = cv2.resize(bin_ocr, (gray.shape[1], gray.shape[0]), interpolation=cv2.INTER_AREA)
    else:
        bin_prev = bin_ocr.copy()

    return bin_ocr, bin_prev, s
