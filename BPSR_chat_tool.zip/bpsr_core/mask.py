from __future__ import annotations
import numpy as np

def apply_icon_mask_to_bins(bin_high: np.ndarray, bin_low: np.ndarray, mask_w: int, mask_h: int):
    """Mask top-left rectangle (icon area) on both bin images (in-place)."""
    if bin_high is None or bin_low is None:
        return
    mw = int(max(0, min(bin_high.shape[1], mask_w)))
    mh = int(max(0, min(bin_high.shape[0], mask_h)))
    if mw <= 0 or mh <= 0:
        return
    bin_high[0:mh, 0:mw] = 255
    bin_low[0:mh, 0:mw] = 255
